﻿Public Class wew
    Dim hasiljumlah As Integer
    Dim bil1, bil2 As Integer
    
    Sub penjumlahan(ByVal a As Integer, ByVal b As Integer)

        hasiljumlah = a + b
        Console.Write("Hasil Penjumlahan : ")
        Console.Write(hasiljumlah)
        Console.WriteLine()
        Console.WriteLine("Kembali ke menu tekan enter")
        Console.ReadLine()
        Console.Clear()
        menu()

    End Sub
    Sub perkalian(ByVal a As Integer, ByVal b As Integer)

        hasiljumlah = a * b
        Console.Write("Hasil Perkalian : ")
        Console.Write(hasiljumlah)
        Console.WriteLine()
        Console.WriteLine("Kembali ke menu tekan enter")
        Console.ReadLine()
        Console.Clear()
        menu()
    End Sub
    Sub pengurangan(ByVal a As Integer, ByVal b As Integer)



        hasiljumlah = a - b
        Console.Write("Hasil Pengurangan : ")
        Console.Write(hasiljumlah)
        Console.WriteLine()
        Console.WriteLine("Kembali ke menu tekan enter")
        Console.ReadLine()
        Console.Clear()
        menu()
    End Sub
    Sub pembagian(ByVal a As Integer, ByVal b As Integer)

        hasiljumlah = a / b
        Console.Write("Hasil Penjumlahan : ")
        Console.Write(hasiljumlah)
        Console.WriteLine()
        Console.WriteLine("Kembali ke menu tekan enter")
        Console.ReadLine()
        Console.Clear()
        menu()
    End Sub
    Sub perpangkatan(ByVal a As Integer, ByVal b As Integer)

        hasiljumlah = 1
        For i = 1 To b
            hasiljumlah = hasiljumlah * a

        Next
        Console.Write("Hasil perpangkatan : ")
        Console.Write(hasiljumlah)
        Console.WriteLine()
        Console.WriteLine("Kembali ke menu tekan enter")
        Console.ReadLine()
        Console.Clear()
        menu()
    End Sub

    Sub integral(ByVal a As Integer, ByVal b As Integer)
        Dim y As Integer
        y = b - a
        Dim jumlah(y) As Integer
        Dim j As Integer
        Dim z As Integer
   
        j = 0

        For i = a To b

            jumlah(j) = ((2 * (i * i) - (4 * i)) + 1)

            j = j + 1
            
        Next
        Console.WriteLine(a & " <= x <= " & b)
        Console.WriteLine("Hasil  : ")
        For z = 0 To y

            Console.Write(jumlah(z).ToString)
            Console.Write(" ")
        Next
        Console.WriteLine()
        Console.WriteLine("Kembali ke menu tekan enter")
        Console.ReadLine()
        Console.Clear()
        menu()
    End Sub
End Class
