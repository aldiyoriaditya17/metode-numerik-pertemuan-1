﻿Module Module1
    Dim a As Integer
    Dim b As Integer

    Dim kalkulator As New wew

    Sub menu()

        Dim pila As Integer
        Console.WriteLine("Bilangan Ke-1: " & a)
        Console.WriteLine("Bilangan Ke-2: " & b)
        Console.WriteLine("       KALKULATOR       ")
        Console.WriteLine("------------------------")
        Console.WriteLine("1.Penjumlahan")
        Console.WriteLine("2.Perkalian")
        Console.WriteLine("3.Pengurangan")
        Console.WriteLine("4.pembagian")
        Console.WriteLine("5.Perpangkatan")
        Console.WriteLine("6.deret dari f(x) = 2x² - 4x + 1")
        Console.Write("Masukan Pilihan : ")
        pila = Console.ReadLine()
        If pila = 1 Then
            kalkulator.penjumlahan(a, b)
        End If
        If pila = 2 Then
            kalkulator.perkalian(a, b)
        End If
        If pila = 3 Then
            kalkulator.pengurangan(a, b)
        End If
        If pila = 4 Then
            kalkulator.pembagian(a, b)
        End If
        If pila = 5 Then
            kalkulator.perpangkatan(a, b)
        End If
        If pila = 6 Then
            kalkulator.integral(a, b)
        End If
    End Sub
    Sub Main()
        Console.Write("Masukan Bilangan Ke-1 : ")
        a = Console.ReadLine()
        Console.Write("Masukan Bilangan Ke-2 : ")
        b = Console.ReadLine()
        Console.Clear()
        menu()
    End Sub

End Module
